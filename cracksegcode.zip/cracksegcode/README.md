# Crack Segmentation Networks for Civil Infrastructure

The paper has been submitted. Once accepted, the relevant code and data of the paper will be made public.

### Raw Model Weight on Four Datasets.

[link](https://pan.baidu.com/s/1blVrG-LX6T9_jXEbeB1eBw?pwd=cv3g )
