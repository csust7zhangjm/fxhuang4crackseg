# -*- coding: utf-8 -*-
import argparse
import os
from collections import OrderedDict
from glob import glob
import random

import numpy as np
import pandas as pd
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
import yaml
from torchvision.transforms import transforms as T
from torch.optim import lr_scheduler
from tqdm import tqdm
from torch.nn import init

from loss import losses
from dataset.dataset import CrackLSDataset
from loss.losses import BCEDiceLoss, DiceLoss, FocalLoss
from metric.metrics import iou_score, f1_loss, miou
from net.UNetImprove import MyNet
from net.HED import HED
from net.RCF import RCF
from net.SegNet import SegNet
from net.DeepCrack import DeepCrack
from utils.utils import AverageMeter, str2bool



#ARCH_NAMES = archs.__all__
#LOSS_NAMES = losses.__all__
#LOSS_NAMES.append('BCEWithLogitsLoss')


def fix_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True


# weights initialization
def weights_init_kaiming(m):
    classname = m.__class__.__name__
    # print(classname)
    if classname.find('Conv') != -1:
        init.kaiming_normal_(m.weight.data, a=0, mode='fan_in') # For old pytorch, you may use kaiming_normal.
    elif classname.find('Linear') != -1:
        init.kaiming_normal_(m.weight.data, a=0, mode='fan_out')
        init.constant_(m.bias.data, 0.0)
    elif classname.find('BatchNorm1d') != -1:
        init.normal_(m.weight.data, 1.0, 0.02)
        init.constant_(m.bias.data, 0.0)


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default=None,
                        help='model name: (default: arch+timestamp)')
    parser.add_argument('--epochs', default=100, type=int, metavar='N',
                        help='number of total epochs to run')
    parser.add_argument('-b', '--batch_size', default=1, type=int,
                        metavar='N', help='mini-batch size (default: 16)')

    # model
    parser.add_argument('--arch', '-a', metavar='ARCH', default='RCF')
    parser.add_argument('--deep_supervision', default=False, type=str2bool)
    parser.add_argument('--input_channels', default=3, type=int,
                        help='input channels')
    parser.add_argument('--num_classes', default=1, type=int,
                        help='number of classes')
    parser.add_argument('--input_w', default=640, type=int,
                        help='image width')
    parser.add_argument('--input_h', default=640, type=int,
                        help='image height')

    # loss
    parser.add_argument('--loss', default='CrossEntropyLoss',
                        choices=['BCEDiceLoss', "BCEWithLogitsLoss", "CrossEntropyLoss", "DiceLoss", "FocalLoss"],
                        help='loss: ' +
                        ' | '.join(['BCEDiceLoss', "FocalLoss"]) +
                        ' (default: BCEDiceLoss)')

    # dataset
    parser.add_argument('--dataset', default='DeepCrack',
                        help='dataset name')
    parser.add_argument('--dataroot', default='',
                        help='dataset name')
    parser.add_argument('--img_ext', default='.jpg',
                        help='image file extension')
    parser.add_argument('--mask_ext', default='.jpg',
                        help='mask file extension')

    # optimizer
    parser.add_argument('--optimizer', default='Adam',
                        choices=['Adam', 'SGD'],
                        help='loss: ' +
                        ' | '.join(['Adam', 'SGD']) +
                        ' (default: Adam)')
    # The start point of learning rate is 1e-3,  then down to the min lr ,
    # which is 5e-3 when the backbone is resnet
    parser.add_argument('--lr', '--learning_rate', default=0.001, type=float,
                        metavar='LR', help='initial learning rate')
    parser.add_argument('--momentum', default=0.9, type=float,
                        help='momentum')
    parser.add_argument('--weight_decay', default=0.0, type=float,
                        help='weight decay')
    parser.add_argument('--nesterov', default=False, type=str2bool,
                        help='nesterov')

    # scheduler
    parser.add_argument('--scheduler', default='CosineAnnealingLR',
                        choices=['CosineAnnealingLR', 'ReduceLROnPlateau', 'MultiStepLR', 'ConstantLR', 'StepLR'])
    parser.add_argument('--min_lr', default=5e-4, type=float,
                        help='minimum learning rate')
    parser.add_argument('--factor', default=0.1, type=float)
    parser.add_argument('--patience', default=2, type=int)
    parser.add_argument('--milestones', default='1,2', type=str)
    parser.add_argument('--gamma', default=2/3, type=float)
    parser.add_argument('--early_stopping', default=-1, type=int,
                        metavar='N', help='early stopping (default: -1)')
    parser.add_argument('--cfg', type=str, metavar="FILE", help='path to config file', )

    parser.add_argument('--num_workers', default=4, type=int)
    parser.add_argument('--save_dir', default='', type=str)
    parser.add_argument('--RESUME', help="whether load pretrained model", default=False, type=bool)

    config = parser.parse_args()

    return config


# args = parser.parse_args()
def train(config, train_loader, model, criterion, optimizer):
    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter(),
                  'dice': AverageMeter(),
                  'mIoU': AverageMeter()}

    model.train()
    result_h = int(config['input_h'] * 1.25)
    result_w = int(config['input_w'] * 1.25)
    pbar = tqdm(total=len(train_loader))
    for index, sample in enumerate(train_loader):
        B, _, H, W = sample['image'].shape
        input = sample['image'].cuda()
        target = sample['mask'].cuda()


        side1, side2, side3, side4, side5, final_seg_res = model(input)
        loss = criterion(final_seg_res, target)
        loss += criterion(side1, target)
        loss += criterion(side2, target)
        loss += criterion(side3, target)
        loss += criterion(side4, target)
        loss += criterion(side5, target)

        final_seg_res = torch.sigmoid(final_seg_res)

        avg_meters['loss'].update(loss.item(), input.size(0))
        iou, dice = iou_score(final_seg_res, target)
        mean_iou = miou(final_seg_res, target)
        avg_meters['iou'].update(iou, B)
        avg_meters['dice'].update(dice, B)
        avg_meters['mIoU'].update(mean_iou, B)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        postfix = OrderedDict([
            ('loss', avg_meters['loss'].avg),
            ('iou', avg_meters['iou'].avg),
            ('dice', avg_meters['dice'].avg),
            ('mIoU', avg_meters['mIoU'].avg),
        ])
        pbar.set_postfix(postfix)
        pbar.update(1)
    pbar.close()

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg),
                        ('dice', avg_meters['dice'].avg),
                        ('mIoU', avg_meters['mIoU'].avg),
                        ])


def validate(config, val_loader, model, criterion):
    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter(),
                  'dice': AverageMeter(),
                  'pixel_accuracy': AverageMeter(),
                  'precision': AverageMeter(),
                  'f1-score': AverageMeter(),
                  'recall': AverageMeter(),
                  'mIoU': AverageMeter()}

    # switch to evaluate mode
    model.eval()
    with torch.no_grad():
        pbar = tqdm(total=len(val_loader))
        for index, sample in enumerate(val_loader):
            B, _, H, W = sample['image'].shape
            input = sample['image'].cuda()
            target = sample['mask'].cuda()

            side1, side2, side3, side4, side5, final_seg_res = model(input)
            # pred batch, class, height, width
            # target: batch, height, width
            loss = criterion(final_seg_res, target)
            loss += criterion(side1, target)
            loss += criterion(side2, target)
            loss += criterion(side3, target)
            loss += criterion(side4, target)
            loss += criterion(side5, target)
            final_seg_res = torch.sigmoid(final_seg_res)

            iou, dice = iou_score(final_seg_res, target)
            mean_iou = miou(final_seg_res, target)
            acc, precision, recall, f1 = f1_loss(target.flatten(1), final_seg_res.flatten(1))
            # output[output >= 0.5] = 1
            # output[output < 0.5] = 0

            avg_meters['loss'].update(loss.item(), input.size(0))
            avg_meters['iou'].update(iou, B)
            avg_meters['dice'].update(dice, B)
            avg_meters['pixel_accuracy'].update(float(acc), B)
            avg_meters['precision'].update(float(precision), B)
            avg_meters['recall'].update(float(recall), B)
            avg_meters['f1-score'].update(float(f1), B)
            avg_meters['mIoU'].update(float(mean_iou), B)

            postfix = OrderedDict([
                ('loss', avg_meters['loss'].avg),
                ('iou', avg_meters['iou'].avg),
                ('dice', avg_meters['dice'].avg),
                ('pixel_accuracy', avg_meters['pixel_accuracy'].avg),
                ('precision', avg_meters['precision'].avg),
                ('recall', avg_meters['recall'].avg),
                ('f1-score', avg_meters['f1-score'].avg),
                ('mIoU', avg_meters['mIoU'].avg),
            ])
            pbar.set_postfix(postfix)
            pbar.update(1)
        pbar.close()
    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg),
                        ('dice', avg_meters['dice'].avg),
                        ('pixel_accuracy', avg_meters['pixel_accuracy'].avg),
                        ('precision', avg_meters['precision'].avg),
                        ('recall', avg_meters['recall'].avg),
                        ('f1-score', avg_meters['f1-score'].avg),
                        ('mIoU', avg_meters['mIoU'].avg),])


def main():
    config = vars(parse_args())

    if config['name'] is None:
        if config['deep_supervision']:
            config['name'] = '%s_%s_wDS' % (config['dataset'], config['arch'])
        else:
            config['name'] = '%s_%s_woDS' % (config['dataset'], config['arch'])

    os.makedirs('Models/%s' % config['name'], exist_ok=True)

    print('-' * 20)
    for key in config:
        print('%s: %s' % (key, config[key]))
    print('-' * 20)

    with open(os.path.join(config['save_dir'], 'Models/%s/config.yml' % config['name']), 'w') as f:
        yaml.dump(config, f)

    # define loss function (criterion)
    if config['loss'] == 'BCEWithLogitsLoss':
        criterion = nn.BCEWithLogitsLoss().cuda()
    elif config['loss'] == 'BCEDiceLoss':
        criterion = BCEDiceLoss()
    elif config['loss'] == 'DiceLoss':
        criterion = DiceLoss()
    elif config['loss'] == 'FocalLoss':
        criterion = FocalLoss()
    else:
        criterion = CEDiceLoss()
    cudnn.benchmark = True


    # create model
    #model = MyNet()
    #model = SegNet()
    #model = HED()
    model = RCF()
    #model = DeepCrack()
    model = model.cuda()

    params = filter(lambda p: p.requires_grad, model.parameters())
    if config['optimizer'] == 'Adam':
        optimizer = optim.Adam(
            params, lr=config['lr'], weight_decay=config['weight_decay'])
    elif config['optimizer'] == 'SGD':
        optimizer = optim.SGD(params, lr=config['lr'], momentum=config['momentum'],
                              nesterov=config['nesterov'], weight_decay=config['weight_decay'])
    else:
        raise NotImplementedError

    if config['scheduler'] == 'CosineAnnealingLR':
        scheduler = lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=config['epochs'], eta_min=config['min_lr'])
    elif config['scheduler'] == 'ReduceLROnPlateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, factor=config['factor'], patience=config['patience'],
                                                   verbose=1, min_lr=config['min_lr'])
    elif config['scheduler'] == 'MultiStepLR':
        scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[int(e) for e in config['milestones'].split(',')], gamma=config['gamma'])
    elif config['scheduler'] == 'ConstantLR':
        scheduler = None
    elif config['scheduler'] == 'StepLR':
        scheduler = lr_scheduler.StepLR(optimizer, step_size=20, gamma=0.5, last_epoch=-1)
    elif config['scheduler'] == 'CycleLR':
        torch.optim.lr_scheduler.CyclicLR(optimizer, config['lr'], config['min_lr'], step_size_up=2000, step_size_down=2000,
                                          mode='triangular', gamma=1.0, scale_fn=None, scale_mode='cycle',
                                          cycle_momentum=True, base_momentum=0.8, max_momentum=0.9, last_epoch=-1)

    else:
        raise NotImplementedError
    start_epoch = 0
    if config['RESUME']:
        checkpoint = torch.load(os.path.join(config['save_dir'], 'Models/%s/last_model.pth' % config['name']))
        model.load_state_dict(checkpoint['net'])
        start_epoch = checkpoint['epoch'] + 1
        optimizer.load_state_dict(checkpoint['optimizer'])
        # scheduler.load_state_dict(checkpoint['scheduler'])

    # Data loading code
    train_img_ids = glob(os.path.join(config['dataroot'],'train', config['dataset'], 'images', '*' + config['img_ext']))
    train_img_ids = [os.path.splitext(os.path.basename(p))[0] for p in train_img_ids]
    val_img_ids = glob(os.path.join(config['dataroot'],'test', config['dataset'], 'images', '*' + config['img_ext']))
    val_img_ids = [os.path.splitext(os.path.basename(p))[0] for p in val_img_ids]


    train_transform = T.Compose([
        T.Resize((config['input_h'], config['input_w'])),
        T.ToTensor(),

    ])

    val_transform = T.Compose([
        T.Resize((config['input_h'], config['input_w'])),
        T.ToTensor(),
    ])

    train_dataset = CrackLSDataset(
        img_ids=train_img_ids,
        img_dir=os.path.join(config['dataroot'], 'train', config['dataset'], 'images'),
        mask_dir=os.path.join(config['dataroot'], 'train', config['dataset'], 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'],
        transform=train_transform)
    val_dataset = CrackLSDataset(
        img_ids=val_img_ids,
        img_dir=os.path.join(config['dataroot'], 'test', config['dataset'], 'images'),
        mask_dir=os.path.join(config['dataroot'], 'test', config['dataset'], 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'],
        transform=val_transform)

    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config['num_workers'],
        drop_last=False)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=False)
    log = OrderedDict([
        ('epoch', []),
        # ('lr', []),
        ('train_loss', []),
        ('train_iou', []),
        ('train_dice', []),
        ('train_mIoU', []),
        ('val_loss', []),
        ('val_iou', []),
        ('val_dice', []),
        ('val_acc', []),
        ('val_pre', []),
        ('val_f1', []),
        ('val_recall', []),
        ('val_mIoU', []),
    ])


    best_iou = 0
    best_dice = 0
    best_pre = 0
    best_recall = 0
    best_f1 = 0
    best_mIoU = 0
    best_epoch = 0
    best_acc = 0
    for epoch in range(start_epoch, config['epochs']):
        print('Epoch [%d/%d]' % (epoch, config['epochs']))
        # train for one epoch
        train_log = train(config, train_loader, model, criterion, optimizer)
        # evaluate on validation set
        val_log = validate(config, val_loader, model, criterion)

        #if config['scheduler'] in ['CosineAnnealingLR', 'StepLR']:
        #    scheduler.step()
        # elif config['scheduler'] == 'ReduceLROnPlateau':
        #     scheduler.step(val_log['loss'])



        log['epoch'].append(epoch)
        # log['lr'].append(scheduler.get_lr())
        log['train_loss'].append(train_log['loss'])
        log['train_iou'].append(train_log['iou'])
        log['train_dice'].append(train_log['dice'])
        log['train_mIoU'].append(train_log['mIoU'])
        log['val_loss'].append(val_log['loss'])
        log['val_iou'].append(val_log['iou'])
        log['val_dice'].append(val_log['dice'])
        log['val_acc'].append(val_log['pixel_accuracy'])
        log['val_pre'].append(val_log['precision'])
        log['val_f1'].append(val_log['f1-score'])
        log['val_recall'].append(val_log['recall'])
        log['val_mIoU'].append(val_log['mIoU'])

        pd.DataFrame(log).to_csv(os.path.join(config['save_dir'], 'Models/%s/log.csv' %
                                 config['name']), index=False)

        if val_log['mIoU'] > best_mIoU:
            torch.save({
                'net': model.state_dict(),
                'epoch': epoch,
                'optimizer': optimizer.state_dict(),
                # 'scheduler': scheduler.state_dict(),
                },
                os.path.join(config['save_dir'], 'Models/%s/%s_best_model_%s_%.5f.pth' %
                             (config['name'], config['dataset'], str(epoch), val_log['iou'])))
            best_iou = val_log['iou']
            best_dice = val_log['dice']
            best_pre = val_log['precision']
            best_recall = val_log['recall']
            best_f1 = val_log['f1-score']
            best_mIoU = val_log['mIoU']
            best_acc = val_log['pixel_accuracy']
            best_epoch = epoch
            print("=> saved best model")
        print('Train==>Loss:%.5f, IoU %.5f, Dice: %.5f, mIoU: %.5f' % (train_log['loss'], train_log['iou'], train_log['dice'], train_log['mIoU']))
        print('-' * 125)
        print('Valid==>Epoch: %d, Loss:%.5f, IoU %.5f, Acc:  %.5f, Dice: %.5f, Pre: %.5f Recall: %.5f F1: %.5f, mIoU %.5f' %
              (epoch, val_log['loss'], val_log['iou'], val_log['pixel_accuracy'], val_log['dice'], val_log['precision'], val_log['recall'], val_log['f1-score'],
               val_log['mIoU']))
        print('-' * 125)
        print('Best==>Epoch: %d, IoU %.5f, Acc: %.5f, Dice %.5f, Pre: %.5f Recall: %.5f F1: %.5f, mIoU %.5f' %
              (best_epoch, best_iou, best_acc, best_dice, best_pre, best_recall, best_f1, best_mIoU))
        print('=' * 125)

        torch.save({
            'net': model.state_dict(),
            'epoch': epoch,
            'optimizer': optimizer.state_dict(),
            # 'scheduler': scheduler.state_dict(),
        },  os.path.join(config['save_dir'], 'Models/%s/last_model.pth' %
                         config['name']))
        torch.cuda.empty_cache()
    # 记录最终结果，省去查看日志的时间


if __name__ == '__main__':
    # 固定种子保证实验可重复性,By fixing the hyper parameter seed to enable my experiment repeatable
    fix_seed(42)
    main()
