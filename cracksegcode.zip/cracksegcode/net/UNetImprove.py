from collections import OrderedDict

from torch.nn import functional as F, init

"""
Code copy from container source code:
https://github.com/allenai/container/blob/main/models.py
"""
import os
import torch
import torch.nn as nn
from functools import partial
import math
from timm.models.layers import trunc_normal_, DropPath
#class GNAM(nn.Module):
#    def __init__(self, channel=32):
#        super(GNAM, self).__init__()
#        self.gn = nn.GroupNorm(32, channel)
#    
#    
#    def forward(self, x):
#        residual = x
#        
#        x = self.gn(x)
#        x = x.permute(0, 2, 3, 1).contiguous()
#        weight_gn = torch.sigmoid(self.gn.weight.data)
#        x = torch.mul(weight_gn, x)
#        x = x.permute(0, 3, 1, 2).contiguous()
#        return torch.sigmoid(x) * residual
class GNAM(nn.Module):
    def __init__(self, channel=32):
        super(GNAM, self).__init__()
        # MaxPool可以使用默认的0填充
        self.max_pool = nn. AdaptiveMaxPool2d((1, 1))
        # AvgPool使用0填充不太合理使用F.pad(),padding_mode使用replicate或者reflect都行
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.gn = nn.GroupNorm(32, channel)
    
    
    def forward(self, x):
        residual = x
        
        max_feature = self.max_pool(x)
        max_feature = self.gn(max_feature)
        max_weight_gn = torch.sigmoid(self.gn.weight.data)
        max_feature = max_feature.permute(0, 2, 3, 1).contiguous()
        max_feature = torch.mul(max_weight_gn, max_feature)
        max_feature = max_feature.permute(0, 3, 1, 2).contiguous()

        avg_feature = self.avg_pool(x)
        avg_feature = self.gn(avg_feature)
        avg_weight_gn = torch.sigmoid(self.gn.weight.data)
        avg_feature = avg_feature.permute(0, 2, 3, 1).contiguous()
        avg_feature = torch.mul(avg_weight_gn, avg_feature)
        avg_feature = avg_feature.permute(0, 3, 1, 2).contiguous()
        
        
        return (max_feature + avg_feature) * residual 


class ShiftDepthWiseConv(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0., shift_size=5):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.dim = in_features
        # 全连接层B, C, K
        self.conv1x1_in = nn.Conv2d(in_features, hidden_features, 1)
        self.dwconv = nn.Conv2d(hidden_features, hidden_features, 3, 1, 1, groups=hidden_features, bias=True)
        self.act = act_layer()
        self.conv1x1_out = nn.Conv2d(hidden_features, out_features, 1)
        self.drop = nn.Dropout(drop)

        self.shift_size = shift_size
        self.pad = shift_size // 2

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        # pdb.set_trace()
        # extrack shape of x:B, N, C ==> N = H * W
        B, C, H, W = x.shape

        # shift op
        padding_H = self.pad * 2 + H
        padding_W = self.pad * 2 + W
        xn = F.pad(x, (self.pad, self.pad, self.pad, self.pad), "constant", 0)
        xs = torch.chunk(xn, self.shift_size, 1)
        x_shift = [torch.roll(x_c, shift, 2) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
        x_cat = torch.cat(x_shift, 1)
        
        x = self.conv1x1_in(x_cat)
        
        # Reverse Y axis Shift
        xs = torch.chunk(x, self.shift_size, 1)
        x_shift = [torch.roll(x_c, -shift, 2) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
        x_cat = torch.cat(x_shift, 1)
        # x_cat = torch.narrow(x_cat, 2, self.pad, H)
        # x = torch.narrow(x_cat, 3, self.pad, W)

        x = self.dwconv(x_cat)
        x = self.act(x)
        x = self.drop(x)

        # Shift And Concat
        # xn = F.pad(x, (self.pad, self.pad, self.pad, self.pad), "constant", 0)
        xs = torch.chunk(x, self.shift_size, 1)
        x_shift = [torch.roll(x_c, shift, 3) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
        x_cat = torch.cat(x_shift, 1)
        # x_s = x_cat.reshape(B, -1, padding_H * padding_W).contiguous()
        # x_shift_c = x_s.transpose(1, 2)

        x = self.conv1x1_out(x_cat)
        # Reverse X axis Shift
        # x = x.transpose(1, 2).view(B, -1, padding_H, padding_W).contiguous()
        xs = torch.chunk(x, self.shift_size, 1)
        x_shift = [torch.roll(x_c, -shift, 3) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
        x_cat = torch.cat(x_shift, 1)
        x = torch.narrow(x_cat, 2, self.pad, H)
        x = torch.narrow(x, 3, self.pad, W)
        x = self.drop(x)
        return x


class SDWBlock(nn.Module):
    """
    Shifted Depth wise block
    """
    def __init__(self, dim, expand_ratio=4.,  drop=0., drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        expand_dim = int(dim * expand_ratio)
        self.dw = ShiftDepthWiseConv(in_features=dim, hidden_features=expand_dim, act_layer=act_layer, drop=drop)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        B, C, H, W = x.shape
        x = x.flatten(2).permute(0, 2, 1).contiguous()
        x = self.norm2(x)
        x = x.transpose(1, 2).view(B, C, H, W).contiguous()
        x = x + self.drop_path(self.dw(x))
        return x


class CBG(nn.Sequential):
    def __init__(self, in_channels, out_channels, ksize=3):
        groups = 1 if ksize == 1 else 32
        norm = nn.BatchNorm2d(out_channels) if groups == 1 else nn.GroupNorm(groups, out_channels)
        super(CBG, self).__init__(
            nn.Conv2d(in_channels, out_channels, kernel_size=(ksize, ksize), padding=(ksize // 2, ksize // 2), groups=groups),
            norm,
            nn.GELU(),
        )


class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, num_blocks, residual=True):
        super(ResidualBlock, self).__init__()
        self.blocks = nn.ModuleList([CBG(in_channels, out_channels, ksize=1)] + [CBG(out_channels, out_channels)
                                                                        for _ in range(num_blocks)])
        self.reduce = nn.Conv2d(num_blocks * out_channels, out_channels, 1)

        self.residual = residual

    def forward(self, x):
        feature = []
        init_feature = None
        for index, block in enumerate(self.blocks):
            x = block(x)
            if index > 0:
                feature.append(x)
            else:
                init_feature = x
        if self.residual:
            return self.reduce(torch.cat(feature, dim=1)) + init_feature

        return self.reduce(torch.cat(feature, dim=1))


class MyNet(nn.Module):
    def __init__(self, num_classes=1):
        super(MyNet, self).__init__()
        self.max_pool = nn.MaxPool2d(2, 2, return_indices=True)
        self.sdw = nn.Sequential(
            SDWBlock(512, expand_ratio=2),
            SDWBlock(512, expand_ratio=2),
        )

        self.max_un_pool = nn.MaxUnpool2d(2, 2)
        self.down1 = ResidualBlock(3, 32, 2)
        self.down2 = ResidualBlock(32, 64, 2)
        self.down3 = ResidualBlock(64, 128, 3)
        self.down4 = ResidualBlock(128, 256, 3)
        self.down5 = ResidualBlock(256, 512, 3)
        
        self.gnam2 = GNAM(64)
        self.gnam3 = GNAM(128)
        self.gnam4 = GNAM(256)
        self.gnam5 = GNAM(512)
        
        
        self.up5 = ResidualBlock(1024, 256, 3, residual=False)
        self.up4 = ResidualBlock(512, 128, 3, residual=False)
        self.up3 = ResidualBlock(256, 64, 3, residual=False)
        self.up2 = ResidualBlock(128, 32, 2, residual=False)
        self.up1 = ResidualBlock(32, 32, 2, residual=False)

        self.out = nn.Sequential(
            nn.Conv2d(32, 32, 3, 1, 1),
            nn.Conv2d(32, num_classes, 1)
        )

    def forward(self, x):
        if x.shape == (3, 640, 640):
            x = x.unsqueeze(0)
        feature1 = self.down1(x)
        x1, indices1 = self.max_pool(feature1)
        feature2 = self.down2(x1)
        x2, indices2 = self.max_pool(feature2)
        feature3 = self.down3(x2)
        x3, indices3 = self.max_pool(feature3)
        feature4 = self.down4(x3)
        x4, indices4 = self.max_pool(feature4)
        feature5 = self.down5(x4)
        x5, indices5 = self.max_pool(feature5)

        x5 = self.sdw(x5)

        up5 = self.max_un_pool(x5, indices5)
        up5 = self.up5(torch.cat([up5, self.gnam5(feature5)], dim=1))

        up4 = self.max_un_pool(up5, indices4)
        up4 = self.up4(torch.cat([up4, self.gnam4(feature4)], dim=1))

        up3 = self.max_un_pool(up4, indices3)
        up3 = self.up3(torch.cat([up3, self.gnam3(feature3)], dim=1))

        up2 = self.max_un_pool(up3, indices2)
        up2 = self.up2(torch.cat([up2, self.gnam2(feature2)], dim=1))

        up1 = self.max_un_pool(up2, indices1)
        up1 = self.up1(up1)
        return self.out(up1)

class MyNetBaseline(nn.Module):
    def __init__(self, num_classes=1, sdw=False, gnam=False):
        super(MyNetBaseline, self).__init__()
        self.max_pool = nn.MaxPool2d(2, 2, return_indices=True)
        self.sdw = nn.Identity()
        if sdw:
          self.sdw = nn.Sequential(
              SDWBlock(512, expand_ratio=2),
              SDWBlock(512, expand_ratio=2),
          )

        self.max_un_pool = nn.MaxUnpool2d(2, 2)
        self.down1 = ResidualBlock(3, 32, 2)
        self.down2 = ResidualBlock(32, 64, 2)
        self.down3 = ResidualBlock(64, 128, 3)
        self.down4 = ResidualBlock(128, 256, 3)
        self.down5 = ResidualBlock(256, 512, 3)
        
        self.gnam2 = nn.Identity()
        self.gnam3 = nn.Identity()
        self.gnam4 = nn.Identity()
        self.gnam5 = nn.Identity()
        if gnam:
          self.gnam2 = GNAM(64)
          self.gnam3 = GNAM(128)
          self.gnam4 = GNAM(256)
          self.gnam5 = GNAM(512)
        
        
        self.up5 = ResidualBlock(1024, 256, 3, residual=False)
        self.up4 = ResidualBlock(512, 128, 3, residual=False)
        self.up3 = ResidualBlock(256, 64, 3, residual=False)
        self.up2 = ResidualBlock(128, 32, 2, residual=False)
        self.up1 = ResidualBlock(32, 32, 2, residual=False)

        self.out = nn.Sequential(
            nn.Conv2d(32, 32, 3, 1, 1),
            nn.Conv2d(32, num_classes, 1)
        )

    def forward(self, x):
        feature1 = self.down1(x)
        x1, indices1 = self.max_pool(feature1)
        feature2 = self.down2(x1)
        x2, indices2 = self.max_pool(feature2)
        feature3 = self.down3(x2)
        x3, indices3 = self.max_pool(feature3)
        feature4 = self.down4(x3)
        x4, indices4 = self.max_pool(feature4)
        feature5 = self.down5(x4)
        x5, indices5 = self.max_pool(feature5)

        x5 = self.sdw(x5)

        up5 = self.max_un_pool(x5, indices5)
        up5 = self.up5(torch.cat([up5, self.gnam5(feature5)], dim=1))

        up4 = self.max_un_pool(up5, indices4)
        up4 = self.up4(torch.cat([up4, self.gnam4(feature4)], dim=1))

        up3 = self.max_un_pool(up4, indices3)
        up3 = self.up3(torch.cat([up3, self.gnam3(feature3)], dim=1))

        up2 = self.max_un_pool(up3, indices2)
        up2 = self.up2(torch.cat([up2, self.gnam2(feature2)], dim=1))

        up1 = self.max_un_pool(up2, indices1)
        up1 = self.up1(up1)
        return self.out(up1)

def load_net(state_dict1: OrderedDict, net2: MyNet):
    state_dict2 = net2.state_dict()
    for key in state_dict1:
        key2 = key.replace('mlp.0', 'sdw.0').replace('0.mlp', '0.dw')
        key2 = key2.replace('mlp.1', 'sdw.1').replace('1.mlp', '1.dw')
        state_dict2[key2] = state_dict1[key]
    net2.load_state_dict(state_dict2, strict=False)


def test_param():
    net1 = VGGBlock(32, 32, 2)
    param_dict1 = net1.state_dict()
    net1.eval()
    net2 = ResidualBlock(32, 32, 2, residual=False)
    param_dict2 = net2.state_dict()
    net2.eval()
    for k in param_dict1:
        param_dict2[k] = param_dict1[k]
    net2.load_state_dict(param_dict2)
    x = torch.randn([2, 32, 12, 12])
    y2 = net2(x)
    y1 = net1(x)
    print((y1 - y2)**2)


def test_unet(state_dict_path):
    net1 = torch.load(state_dict_path)
    net2 = MyNet()
    net2.eval()
    load_net(net1['net'], net2)
    net1['net'] = net2.state_dict()
    torch.save(net1, 'reload_' + state_dict_path)
    # x = torch.randn([2, 3, 512, 512])
    # y1 = net1(x)
    # y2 = net2(x)
    # print(net1)
    # torch.save(net2.state_dict(), "net.pth")
    # print(net2)
    # print((y1 - y2) ** 2)
    # print(net1.state_dict().keys())
    # print(net2.state_dict().keys())


def test_myNet():
    x = torch.randn([2, 3, 512, 512])
    net = MyNet()
    y = net(x)
    torch.save(net.state_dict(), "net.pth")
    print(y.shape)


if __name__ == '__main__':
    # test_unet('CFD_best_model_27_0.57546.pth')
    test_myNet()