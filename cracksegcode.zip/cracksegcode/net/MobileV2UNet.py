import logging
import math
from functools import reduce

import torch
from timm.models.layers import DropPath, trunc_normal_
from torch import nn
from torch.nn import functional as F, init

from net.backbone.MobileNetV2 import MobileNetV2, InvertedResidual, TransposeInvertedResidual


class shiftmlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0., shift_size=5):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.dim = in_features
        # 全连接层B, C, K
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.dwconv = nn.Conv2d(hidden_features, hidden_features, 3, 1, 1, groups=hidden_features, bias=True)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

        self.shift_size = shift_size
        self.pad = shift_size // 2

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    #     def shift(x, dim):
    #         x = F.pad(x, "constant", 0)
    #         x = torch.chunk(x, shift_size, 1)
    #         x = [ torch.roll(x_c, shift, dim) for x_s, shift in zip(x, range(-pad, pad+1))]
    #         x = torch.cat(x, 1)
    #         return x[:, :, pad:-pad, pad:-pad]

    def forward(self, x):
        # pdb.set_trace()
        # extrack shape of x:B, N, C ==> N = H * W
        B, C, H, W = x.shape

        # shift op
        padding_H = self.pad * 2 + H
        padding_W = self.pad * 2 + W
        xn = F.pad(x, (self.pad, self.pad, self.pad, self.pad), "constant", 0)
        xs = torch.chunk(xn, self.shift_size, 1)
        x_shift = [torch.roll(x_c, shift, 2) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
        x_cat = torch.cat(x_shift, 1)


        x_s = x_cat.reshape(B, C, padding_H * padding_W).contiguous()
        x_shift_r = x_s.transpose(1, 2)

        x = self.fc1(x_shift_r)
        x = x.transpose(1, 2).view(B, -1, padding_H, padding_W).contiguous()
        # Reverse Y axis Shift
        xs = torch.chunk(x, self.shift_size, 1)
        x_shift = [torch.roll(x_c, -shift, 2) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
        x_cat = torch.cat(x_shift, 1)
        x_cat = torch.narrow(x_cat, 2, self.pad, H)
        x = torch.narrow(x_cat, 3, self.pad, W)

        x = self.dwconv(x)
        x = self.act(x)
        x = self.drop(x)

        # xn = x.transpose(1, 2).view(B, C, H, W).contiguous()
        # Shift And Concat
        xn = F.pad(x, (self.pad, self.pad, self.pad, self.pad), "constant", 0)
        xs = torch.chunk(xn, self.shift_size, 1)
        x_shift = [torch.roll(x_c, shift, 3) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
        x_cat = torch.cat(x_shift, 1)
        x_s = x_cat.reshape(B, -1, padding_H * padding_W).contiguous()
        x_shift_c = x_s.transpose(1, 2)

        x = self.fc2(x_shift_c)
        # Reverse X axis Shift
        x = x.transpose(1, 2).view(B, -1, padding_H, padding_W).contiguous()
        xs = torch.chunk(x, self.shift_size, 1)
        x_shift = [torch.roll(x_c, -shift, 3) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
        x_cat = torch.cat(x_shift, 1)
        x = torch.narrow(x_cat, 2, self.pad, H)
        x = torch.narrow(x, 3, self.pad, W)
        x = self.drop(x)
        return x


# 相当于MLP-Mixer的MixerBlock
class MLPBlock(nn.Module):
    def __init__(self, dim, mlp_ratio=4.,  drop=0., drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = shiftmlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        B, C, H, W = x.shape
        x = x.flatten(2).permute(0, 2, 1).contiguous()
        x = self.norm2(x)
        x = x.transpose(1, 2).view(B, C, H, W).contiguous()
        x = x + self.drop_path(self.mlp(x))
        return x


# class DWConv(nn.Module):
#     def __init__(self, dim=768):
#         super(DWConv, self).__init__()
#         self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)
#
#     def forward(self, x, H, W):
#         B, N, C = x.shape
#         x = x.transpose(1, 2).view(B, C, H, W)
#         x = self.dwconv(x)
#         x = x.flatten(2).transpose(1, 2)
#
#         return x

class SKConv(nn.Module):
    def __init__(self, in_channels, out_channels,stride=1,M=2,r=16,L=32):
        '''
        :param in_channels:  输入通道维度
        :param out_channels: 输出通道维度   原论文中 输入输出通道维度相同
        :param stride:  步长，默认为1
        :param M:  分支数
        :param r: 特征Z的长度，计算其维度d 时所需的比率（论文中 特征S->Z 是降维，故需要规定 降维的下界）
        :param L:  论文中规定特征Z的下界，默认为32
        采用分组卷积： groups = 32,所以输入channel的数值必须是group的整数倍
        '''
        super(SKConv, self).__init__()
        d = max(in_channels//r, L)   # 计算从向量C降维到 向量Z 的长度d
        self.M = M
        self.out_channels = out_channels
        self.conv = nn.ModuleList()  # 根据分支数量 添加 不同核的卷积操作
        for i in [3, 5, 7]:
            # 为提高效率，原论文中 扩张卷积5x5为 （3X3，dilation=2）来代替。 且论文中建议组卷积G=32
            self.conv.append(nn.Sequential(nn.Conv2d(in_channels, out_channels, i, 1, padding=i // 2, groups=1280),
                                           nn.BatchNorm2d(out_channels),
                                           nn.ReLU(inplace=True)))
        self.fc1 = nn.Sequential(nn.Conv2d(out_channels, d, 1),
                                   nn.BatchNorm2d(d),
                                   nn.ReLU(inplace=True))   # 降维
        self.fc2 = nn.Conv2d(d, out_channels, 1, 1)  # 升维

    def forward(self, input):
        res = 0
        for block in self.conv:
            res += block(input)
        res = self.fc1(res)
        res = self.fc2(res)
        return res    # [batch_size,out_channels,H,W]


class HybridDilatedConv(nn.Module):
    def __init__(self, dims, expand=4):
        super(HybridDilatedConv, self).__init__()
        hidden = dims * expand
        self.conv1 = nn.Sequential(
            nn.Conv2d(dims, hidden, 1),
            nn.BatchNorm2d(hidden),
            nn.ReLU6(inplace=True),
            nn.Conv2d(hidden, hidden, kernel_size=(1, 7), padding=(0, 7 // 2), groups=hidden),
            nn.Conv2d(hidden, hidden, kernel_size=(7, 1), padding=(7 // 2, 0), groups=hidden),
            nn.BatchNorm2d(hidden),
            nn.ReLU6(inplace=True),
            nn.Conv2d(hidden, dims, 1),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(dims, hidden, 1),
            nn.BatchNorm2d(hidden),
            nn.ReLU6(inplace=True),
            nn.Conv2d(hidden, hidden, kernel_size=(1, 11), padding=(0, 11 // 2), groups=hidden),
            nn.Conv2d(hidden, hidden, kernel_size=(11, 1), padding=(11 // 2, 0), groups=hidden),
            nn.BatchNorm2d(hidden),
            nn.ReLU6(inplace=True),
            nn.Conv2d(hidden, dims, 1),
        )

    def forward(self, x):
        return self.conv1(x) + self.conv2(x)


class MobileNetV2_UNet(nn.Module):
    def __init__(self, pre_trained='net/mobilenet_v2.pth.tar'):
        super(MobileNetV2_UNet, self).__init__()

        self.backbone = MobileNetV2()
        # 修改backbone的stride，使得网络只下采样16倍
        # self.backbone.features[0][0].stride = (1, 1)
        # self.center = SKConv(1280, 1280, stride=1, M=3, r=32)
        self.mlp3 = nn.Sequential(
            MLPBlock(32, mlp_ratio=6),
            MLPBlock(32, mlp_ratio=6)
        )
        self.mlp4 = nn.Sequential(
            MLPBlock(96, mlp_ratio=4),
            MLPBlock(96, mlp_ratio=4)
        )
        self.dconv1 = nn.ConvTranspose2d(in_channels=1280, out_channels=96, stride=2, kernel_size=4, padding=1)
        self.invres1 = InvertedResidual(192, 96, 1, 6)

        self.dconv2 = nn.ConvTranspose2d(in_channels=96, out_channels=32, stride=2, kernel_size=4, padding=1)
        self.invres2 = InvertedResidual(64, 32, 1, 6)


        self.dconv3 = nn.ConvTranspose2d(in_channels=32, out_channels=24, stride=2, kernel_size=4, padding=1)
        self.invres3 = InvertedResidual(48, 24, 1, 6)
        self.dconv4 = nn.ConvTranspose2d(in_channels=24, out_channels=16, stride=2, kernel_size=4, padding=1)
        self.invres4 = InvertedResidual(32, 16, 1, 6)
        self.out = nn.Sequential(
            nn.Conv2d(16, 16, 3, 1, 1),
            nn.Conv2d(16, 1, 1)
        )

        self._init_weights()

        if pre_trained is not None:
            self.backbone.load_state_dict(torch.load(pre_trained, map_location=torch.device('cpu')))

    def forward(self, x):
        B, C, H, W = x.shape
        assert (B // 4) * 4 == B
        for n in range(0, 2):  # 2
            x = self.backbone.features[n](x)
        x1 = x

        for n in range(2, 4):  # 2
            x = self.backbone.features[n](x)
        # Texture spatial feature
        x2 = x

        for n in range(4, 7):  # 3
            x = self.backbone.features[n](x)
        # 56 x 56
        x3 = x

        for n in range(7, 14):  # 7
            x = self.backbone.features[n](x)
        # 28 x 28
        x4 = x

        for n in range(14, 19):  # 5
            x = self.backbone.features[n](x)
        # 14 x 14
        x5 = x
        # print("bottleneck.shape:", x5.shape)
        up1 = torch.cat([
            self.mlp4(x4),
            self.dconv1(x5)
        ], dim=1)
        up1 = self.invres1(up1)

        up2 = torch.cat([
            x3,
            self.dconv2(up1)
        ], dim=1)
        up2 = self.invres2(up2)

        up3 = torch.cat([
            x2,
            self.dconv3(up2)
        ], dim=1)
        up3 = self.invres3(up3)

        up4 = torch.cat([
            x1,
            self.dconv4(up3)
        ], dim=1)
        up4 = self.invres4(up4)
        up4 = F.interpolate(up4, scale_factor=2, mode='bilinear', align_corners=False)

        patch_out = self.out(up4)

        return patch_out

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()


def test_skconv():
    x = torch.randn([2, 1280, 14, 14])
    block = SKConv(1280, 1280, 1, 3, 32)
    y = block(x)
    print(y.shape)


def test_a_net():
    net = MobileNetV2_UNet(pre_trained=None)
    x = torch.randn(2, 3, 448, 448)
    torch.save(net.state_dict(), "net.pth")
    # crop_input = torch.cat([x[:, :, :224, :224], x[:, :, :224, 224:], x[:, :, 224:, :224],
    #                         x[:, :, 224:, 224:], x[:, :, 224:, 224:]], dim=0)
    # crop_input = F.interpolate(crop_input, size=x.shape[2:], mode='bilinear')
    y1 = net(x)
    print("output, shape:", y1.shape)
    print("min:", y1.min(), "max:", y1.max(), "mean:", y1.mean(), "std:", y1.std())
    print(net)


if __name__ == '__main__':
    # Debug
    # logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    # test_shift_convblock()
    test_a_net()
    # test_skconv()