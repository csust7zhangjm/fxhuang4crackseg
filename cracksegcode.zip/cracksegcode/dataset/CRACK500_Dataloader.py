import os

import cv2
import numpy as np
import torch
import torch.utils.data
from albumentations import Compose, Resize, Normalize
from albumentations.pytorch.transforms import ToTensor, ToTensorV2


class CRACK500Dataset(torch.utils.data.Dataset):
    def __init__(self, img_ids, input_h, input_w, img_dir, crop_dir, mask_dir, img_ext, mask_ext, transform=None):
        """
        Args:
            img_ids (list): Image ids.
            img_dir: Image file directory.
            mask_dir: Mask file directory.
            img_ext (str): Image file extension.
            mask_ext (str): Mask file extension.
            num_classes (int): Number of classes.
            transform (Compose, optional): Compose transforms of albumentations. Defaults to None.

        Note:
            Make sure to put the files as the following structure:
            <dataset name>
            ├── images
            |   ├── 0a7e06.jpg
            │   ├── 0aab0a.jpg
            │   ├── 0b1761.jpg
            │   ├── ...
            |
            └── masks
                ├── 0
                ├   ├── 0a7e06.png
                ├   ├── 0aab0a.png
                ├   ├── 0b1761.png
                ├   ├── ...
                ├
                ├── 1
                ├   ├── 0a7e06.png
                ├   ├── 0aab0a.png
                ├   ├── 0b1761.png
                ├   ├── ...
                ...
        """
        self.img_ids = img_ids
        self.input_h = input_h
        self.input_w = input_w
        self.img_dir = img_dir
        self.crop_dir = crop_dir
        self.mask_dir = mask_dir
        self.img_ext = img_ext
        self.mask_ext = mask_ext
        self.transform = transform

    def __len__(self):
        return len(self.img_ids)

    def __getitem__(self, idx):
        img_id = self.img_ids[idx]
        # 当前训练的patch，获取h， w等信息
        crop_img = cv2.imread(os.path.join(self.crop_dir, img_id + self.img_ext))

        # 根据img_id信息提取原图的image_id(image_name), start_w, start_h 等信息
        split_list = img_id.split('_')
        img_id = split_list[0] + '_' + split_list[1]
        img = cv2.imread(os.path.join(self.img_dir, img_id + self.img_ext))
        mask = cv2.imread(os.path.join(self.mask_dir, img_id + self.mask_ext), cv2.IMREAD_GRAYSCALE)[..., None]

        # 获取Patch高宽
        CROP_H, CROP_W = crop_img.shape[:2]
        # 获取原图高宽
        IMAGE_H, IMAGE_W = img.shape[:2]

        # 从原图剪切时往上下左右四个方向分别padding的像素个数
        GAP_LEFT = (self.input_w - CROP_W) // 2
        GAP_RIGHT = GAP_LEFT

        GAP_UP = (self.input_h - CROP_H) // 2
        GAP_DOWN = GAP_UP

        start_w = int(split_list[2]) - 1
        start_h = int(split_list[3]) - 1

        if GAP_LEFT > start_w:
            GAP_LEFT = start_w
            GAP_RIGHT = self.input_w - CROP_W - GAP_LEFT
        elif GAP_RIGHT + CROP_W + start_w > IMAGE_W:
            GAP_RIGHT = IMAGE_W - start_w - CROP_W
            GAP_LEFT = self.input_w - CROP_W - GAP_RIGHT

        if GAP_UP > start_h:
            GAP_UP = start_h
            GAP_DOWN = self.input_h - CROP_H - GAP_UP  # 2 * GAP_DOWN - GAP_UP
        elif GAP_DOWN + CROP_H + start_h > IMAGE_H:
            GAP_DOWN = IMAGE_H - start_h - CROP_H
            GAP_UP = self.input_h - CROP_H - GAP_DOWN

        img = img[start_h - GAP_UP: start_h - GAP_UP + self.input_h, start_w - GAP_LEFT: start_w - GAP_LEFT + self.input_w]
        mask = mask[start_h - GAP_UP: start_h - GAP_UP + self.input_h, start_w - GAP_LEFT: start_w - GAP_LEFT + self.input_w]
        if self.transform is not None:
            augmented = self.transform(image=img.copy(), mask=mask)
            img = augmented['image']
            mask = augmented['mask']

        img = img.astype('float32') / 255
        img = img.transpose(2, 0, 1)
        mask = mask.astype('float32') / 255
        mask = mask.transpose(2, 0, 1)

        return img, mask, {'img_id': self.img_ids[idx], 'GAP_UP': GAP_UP, 'GAP_DOWN': GAP_DOWN,
                           'GAP_LEFT': GAP_LEFT, 'GAP_RIGHT': GAP_RIGHT}


if __name__ == '__main__':
    input_h = 640
    input_w = 960
    batch_size = 3
    val_transform = Compose([
        # ToTensorV2()
        Normalize(),
    ])
    val_img_ids = ['20160306_104456_1281_1']
    img_ext = '.jpg'
    mask_ext = '.jpg'
    dataroot = 'C:\\Users\\Administrator\\Desktop\\pavement crack datasets\\CRACK500\\CRACK500\\test'

    val_img_ids = os.listdir(os.path.join(dataroot, 'crop_masks'))
    val_img_ids = [os.path.splitext(os.path.basename(p))[0] for p in val_img_ids]
    val_dataset = CRACK500Dataset(
        img_ids=val_img_ids,
        input_h=input_h,
        input_w=input_w,
        img_dir=os.path.join(dataroot, 'images'),
        mask_dir=os.path.join(dataroot, 'masks'),
        crop_dir=os.path.join(dataroot, 'crop_masks'),
        img_ext=img_ext,
        mask_ext=mask_ext,
        transform=val_transform)

    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=1,
        drop_last=True)
    for image, mask, meta in val_loader:
        # image = image.cuda()
        # mask = mask.cuda()
        # edge = edge.cuda()
        cls = torch.sum(mask.flatten(1), dim=1).view(mask.size(0), -1)
        res = []
        for i in range(batch_size):
            res.append(image[i:i + 1, :, meta['GAP_UP'][i]: input_h - meta['GAP_DOWN'][i],
                       meta['GAP_LEFT'][i]: input_w - meta['GAP_RIGHT'][i]])
        res = torch.cat(res, dim=0)
        # print(image.shape, image.max(), image.min(), meta)
        image = image[-1].permute(1, 2, 0).contiguous().data.cpu().numpy() * 255
        mask = mask[-1].permute(1, 2, 0).contiguous().data.cpu().numpy() * 255
        # edge = edge[0].data.cpu().numpy()
        # body = body[0].data.cpu().numpy()
        image = image.reshape(input_h, input_w, 3).astype(np.uint8)
        mask = mask.reshape(input_h, input_w, 1).astype(np.uint8)


        print(res.shape)
        # print("origin mask:", cls)
        # cls[cls > 0] = 0.95
        # cls[cls <= 0] = 0.05
        # print(" mask:", cls)
        # cv2.imshow("img", image)
        # cv2.imshow("mask", mask)
        # # cv2.imshow("edge", edge)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
