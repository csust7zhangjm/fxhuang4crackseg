import os
import cv2
import torch
import random
import numpy as np
from glob import glob
from torch.utils.data import Dataset
import h5py
from scipy.ndimage.interpolation import zoom
from torchvision import transforms
import itertools
from scipy import ndimage
from torch.utils.data.sampler import Sampler
from torchvision.transforms import transforms as T
import matplotlib.pyplot as plt
from PIL import Image


class Dataset(torch.utils.data.Dataset):
    def __init__(self, img_ids, img_dir, mask_dir, img_ext, mask_ext, num_classes, transform=None):
        """
        Args:
            img_ids (list): Image ids.
            img_dir: Image file directory.
            mask_dir: Mask file directory.
            img_ext (str): Image file extension.
            mask_ext (str): Mask file extension.
            num_classes (int): Number of classes.
            transform (Compose, optional): Compose transforms of albumentations. Defaults to None.
        
        Note:
            Make sure to put the files as the following structure:
            <dataset name>
            ├── images
            |   ├── 0a7e06.jpg
            │   ├── 0aab0a.jpg
            │   ├── 0b1761.jpg
            │   ├── ...
            |
            └── masks
                ├── 0
                ├   ├── 0a7e06.png
                ├   ├── 0aab0a.png
                ├   ├── 0b1761.png
                ├   ├── ...
                ├
                ├── 1
                ├   ├── 0a7e06.png
                ├   ├── 0aab0a.png
                ├   ├── 0b1761.png
                ├   ├── ...
                ...
        """
        self.img_ids = img_ids
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.img_ext = img_ext
        self.mask_ext = mask_ext
        self.num_classes = num_classes
        self.transform = transform
        self.norm = T.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225),)

    def __len__(self):
        return len(self.img_ids)

    def __getitem__(self, idx):
        img_id = self.img_ids[idx]
        image = Image.open(os.path.join(self.img_dir, img_id + self.img_ext))
        mask = Image.open(os.path.join(self.mask_dir, img_id + self.mask_ext))

        image = image.convert('RGB')
        mask = mask.convert('L')
        if self.transform is not None:
            image = self.norm(self.transform(image))

            mask = self.transform(mask)
        mask[mask > 0] = 1
        sample = {'img_id': img_id}
        # sample = {'image': torch.Tensor(img), 'mask': torch.Tensor(mask)}

        return image, mask, sample


class SegDataSets(Dataset):
    def __init__(self, img_ids, sup_img_dir, unsup_img_dir, mask_dir, img_ext, mask_ext, num_classes, sup_num, transform=None):
        """
        Args:
            img_ids (list): Image ids.
            img_dir: Image file directory.
            mask_dir: Mask file directory.
            img_ext (str): Image file extension.
            mask_ext (str): Mask file extension.
            num_classes (int): Number of classes.
            transform (Compose, optional): Compose transforms of albumentations. Defaults to None.

        Note:
            Make sure to put the files as the following structure:
            <dataset name>
            ├── images
            |   ├── 0a7e06.jpg
            │   ├── 0aab0a.jpg
            │   ├── 0b1761.jpg
            │   ├── ...
            |
            └── masks
                ├── 0
                ├   ├── 0a7e06.png
                ├   ├── 0aab0a.png
                ├   ├── 0b1761.png
                ├   ├── ...
                ├
                ├── 1
                ├   ├── 0a7e06.png
                ├   ├── 0aab0a.png
                ├   ├── 0b1761.png
                ├   ├── ...
                ...
        """
        self.img_ids = img_ids
        self.sup_img_dir = sup_img_dir
        self.unsup_img_dir = unsup_img_dir
        self.mask_dir = mask_dir
        self.img_ext = img_ext
        self.mask_ext = mask_ext
        self.num_classes = num_classes
        self.transform = transform
        self.norm = T.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225),)
        self.supervise_num = sup_num

    def __len__(self):
        return len(self.img_ids)

    def __getitem__(self, idx):
        img_id = self.img_ids[idx]

        if idx >= self.supervise_num:
            img = Image.open(os.path.join(self.unsup_img_dir, img_id + self.img_ext))
            mask = Image.from_numpy(np.zeros((img.shape[0], img.shape[1], 1)))
        else:
            img = Image.open(os.path.join(self.sup_img_dir, img_id + self.img_ext))
            mask = Image.open(os.path.join(self.mask_dir, img_id + self.mask_ext), cv2.IMREAD_GRAYSCALE)[..., None]



        img = img.astype('float32')
        # print(np.max(img), np.min(img))
        img = img.transpose(2, 0, 1)
        mask = mask.astype('float32') / 255
        # print(np.max(mask), np.min(mask))
        mask = mask.transpose(2, 0, 1)
        # edge = edge.astype('float32') / 255
        # edge = edge.transpose(2, 0, 1)

        return img, mask, {'img_id': img_id}


def random_rot_flip(image, label=None):
    k = np.random.randint(0, 4)
    image = np.rot90(image, k)
    axis = np.random.randint(0, 2)
    image = np.flip(image, axis=axis).copy()
    if label is not None:
        label = np.rot90(label, k)
        label = np.flip(label, axis=axis).copy()
        return image, label
    else:
        return image


def random_rotate(image, label):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0, reshape=False)
    return image, label


def color_jitter(image):
    if not torch.is_tensor(image):
        np_to_tensor = transforms.ToTensor()
        image = np_to_tensor(image)

    # s is the strength of color distortion.
    s = 1.0
    jitter = transforms.ColorJitter(0.8 * s, 0.8 * s, 0.8 * s, 0.2 * s)
    return jitter(image)


# class CTATransform(object):
#     def __init__(self, output_size, cta):
#         self.output_size = output_size
#         self.cta = cta
#
#     def __call__(self, sample, ops_weak, ops_strong):
#         image, label = sample["image"], sample["label"]
#         image = self.resize(image)
#         label = self.resize(label)
#         to_tensor = transforms.ToTensor()
#
#         # fix dimensions
#         image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
#         label = torch.from_numpy(label.astype(np.uint8))
#
#         # apply augmentations
#         image_weak = augmentations.cta_apply(transforms.ToPILImage()(image), ops_weak)
#         image_strong = augmentations.cta_apply(image_weak, ops_strong)
#         label_aug = augmentations.cta_apply(transforms.ToPILImage()(label), ops_weak)
#         label_aug = to_tensor(label_aug).squeeze(0)
#         label_aug = torch.round(255 * label_aug).int()
#
#         sample = {
#             "image_weak": to_tensor(image_weak),
#             "image_strong": to_tensor(image_strong),
#             "label_aug": label_aug,
#         }
#         return sample
#
#     def cta_apply(self, pil_img, ops):
#         if ops is None:
#             return pil_img
#         for op, args in ops:
#             pil_img = OPS[op].f(pil_img, *args)
#         return pil_img
#
#     def resize(self, image):
#         x, y = image.shape
#         return zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=0)


class RandomGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample["image"], sample["label"]
        # ind = random.randrange(0, img.shape[0])
        # image = img[ind, ...]
        # label = lab[ind, ...]
        if random.random() > 0.5:
            image, label = random_rot_flip(image, label)
        elif random.random() > 0.5:
            image, label = random_rotate(image, label)
        x, y = image.shape
        image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=0)
        label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.uint8))
        sample = {"image": image, "label": label}
        return sample


class WeakStrongAugment(object):
    """returns weakly and strongly augmented images

    Args:
        object (tuple): output size of network
    """

    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample["image"], sample["label"]
        image = self.resize(image)
        label = self.resize(label)
        # weak augmentation is rotation / flip
        image_weak, label = random_rot_flip(image, label)
        # strong augmentation is color jitter
        image_strong = color_jitter(image_weak).type("torch.FloatTensor")
        # fix dimensions
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        image_weak = torch.from_numpy(image_weak.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.uint8))

        sample = {
            "image": image,
            "image_weak": image_weak,
            "image_strong": image_strong,
            "label_aug": label,
        }
        return sample

    def resize(self, image):
        x, y = image.shape
        return zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=0)


class TwoStreamBatchSampler(Sampler):
    """Iterate two sets of indices

    An 'epoch' is one iteration through the primary indices.
    During the epoch, the secondary indices are iterated through
    as many times as needed.
    """

    def __init__(self, primary_indices, secondary_indices, batch_size, secondary_batch_size):
        self.primary_indices = primary_indices
        self.secondary_indices = secondary_indices
        self.secondary_batch_size = secondary_batch_size
        self.primary_batch_size = batch_size
        #print(len(self.primary_indices), self.primary_batch_size)
        assert len(self.primary_indices) >= self.primary_batch_size > 0
        assert len(self.secondary_indices) >= self.secondary_batch_size > 0

    def __iter__(self):
        primary_iter = iterate_once(self.primary_indices)
        secondary_iter = iterate_eternally(self.secondary_indices)
        return (
            primary_batch + secondary_batch
            for (primary_batch, secondary_batch) in zip(
                grouper(primary_iter, self.primary_batch_size),
                grouper(secondary_iter, self.secondary_batch_size),
            )
        )

    def __len__(self):
        return len(self.primary_indices) // self.primary_batch_size


def iterate_once(iterable):
    return np.random.permutation(iterable)


def iterate_eternally(indices):
    def infinite_shuffles():
        while True:
            yield np.random.permutation(indices)

    return itertools.chain.from_iterable(infinite_shuffles())


def grouper(iterable, n):
    "Collect data into fixed-length chunks or blocks"
    # grouper('ABCDEFG', 3) --> ABC DEF"
    args = [iter(iterable)] * n
    return zip(*args)
