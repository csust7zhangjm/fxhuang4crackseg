from random import random

import numpy as np
import os
import cv2
import torch
from PIL import Image
from albumentations import Compose, Normalize, Resize

from torch.utils.data import Dataset

EXTENSIONS = ['.jpg', '.png']


def load_image(file):
    return Image.open(file)


def is_image(filename):
    return any(filename.endswith(ext) for ext in EXTENSIONS)


def is_label(filename):
    return filename.endswith("_labelTrainIds.png")


def image_path(root, basename, extension):
    return os.path.join(root, f'{basename}{extension}')


def image_path_city(root, name):
    return os.path.join(root, f'{name}')


def image_basename(filename):
    return os.path.basename(os.path.splitext(filename)[0])


class VOC12(Dataset):

    def __init__(self, root, input_transform=None, target_transform=None):
        self.images_root = os.path.join(root, 'images')
        self.labels_root = os.path.join(root, 'labels')

        self.filenames = [image_basename(f)
                          for f in os.listdir(self.labels_root) if is_image(f)]
        self.filenames.sort()

        self.input_transform = input_transform
        self.target_transform = target_transform

    def __getitem__(self, index):
        filename = self.filenames[index]

        image = Image.open(os.path.join(self.images_root, filename, self.ima)).convert('RGB')
        label = load_image(f).convert('P')
        with open(image_path(self.labels_root, filename, '.png'), 'rb') as f:
            label = load_image(f).convert('P')

        if self.input_transform is not None:
            image = self.input_transform(image)
        if self.target_transform is not None:
            label = self.target_transform(label)

        return image, label

    def __len__(self):
        return len(self.filenames)


class CityscapesDataset(Dataset):

    def __init__(self, img_ids, img_root, mask_root, img_ext, mask_ext, num_classes, transform, scale=True):
        self.img_ids = img_ids
        self.img_root = img_root
        self.mask_root = mask_root
        self.img_ext = img_ext
        self.mask_ext = mask_ext
        self.num_classes = num_classes
        self.scale = scale
        self.transform = transform

    def __getitem__(self, index):
        img_id = self.img_ids[index]
        image = Image.open(os.path.join(self.img_root, img_id + self.img_ext)).convert("RGB")
        image = np.array(image)
        mask = Image.open(os.path.join(self.mask_root, img_id + self.mask_ext))  # [..., None]
        mask = np.array(mask)
        mask = cv2.medianBlur(mask, ksize=5)

        if self.transform is not None:
            augmented = self.transform(image=image, mask=mask)
            image = augmented['image']
            mask = augmented['mask']

        image = image.astype('float32')
        image = image.transpose(2, 0, 1)
        # mask = mask.transpose(2, 0, 1)
        return image, mask, img_id

    def __len__(self):
        return len(self.img_ids)


if __name__ == "__main__":
    val_transform = Compose([
        Resize(512, 1024),
        # ToTensorV2()
        Normalize(),
    ])
    val_img_ids = ['aachen_000009_000019', 'aachen_000010_000019',
                   'aachen_000011_000019']
    img_ext = '.png'
    mask_ext = '.png'
    dataroot = 'C:\\Users\\Administrator\\Desktop\\SODDataset\\cityscapes\\train'

    val_dataset = CityscapesDataset(
        img_ids=val_img_ids,
        img_root=os.path.join(dataroot, 'images'),
        mask_root=os.path.join(dataroot, 'masks'),
        img_ext=img_ext,
        mask_ext=mask_ext,
        num_classes=6,
        transform=val_transform)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=2,
        shuffle=True,
        num_workers=1,
        drop_last=True)

    for image, mask, name in val_loader:
        # image = image.cuda()
        # mask = mask.cuda()
        # edge = edge.cuda()
        cls = torch.sum(mask.flatten(1), dim=1).view(mask.size(0), -1)
        print(mask.shape, image.max(), image.min())
        image = image[0].permute(1, 2, 0).contiguous().data.cpu().numpy() * 255
        mask = mask[0].data.cpu().numpy()
        # edge = edge[0].data.cpu().numpy()
        # body = body[0].data.cpu().numpy()
        image = image.reshape(512, 1024, 3).astype(np.uint8)
        mask = mask.reshape(512, 1024).astype(np.uint8)
        m = np.zeros((512, 1024))
        m[mask == 5] = 255
        # body = body.reshape(448, 448, 1)
        # edge = edge.reshape(448, 448, 1)
        print("origin mask:", cls)
        cls[cls > 0] = 0.95
        cls[cls <= 0] = 0.05
        print(" mask:", cls)
        cv2.imshow("img", image)
        cv2.imshow("mask", m)
        # cv2.imshow("edge", edge)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
