import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from segmentation_models_pytorch.losses import SoftBCEWithLogitsLoss
from LovaszSoftmax.pytorch.lovasz_losses import lovasz_hinge

__all__ = ['BCEDiceLoss', 'LovaszHingeLoss']


class BCEDiceLoss(nn.Module):

    def __init__(self):
        """
        因为有统计过像素值之间的差距是2.8:1约等于3:1那么就让weight:0.25
        """
        super().__init__()
        self.focal = nn.BCEWithLogitsLoss()
        self.dice = DiceLoss()
        # self.iou = SoftIoULoss(1)
        # self.sr_loss = None
        # if sr_loss == 'MSE':
        #     self.sr_loss = nn.MSELoss()
        # elif sr_loss == 'L1':
        #     self.sr_loss = nn.L1Loss()
        # else:
        #     raise NotImplementedError(f"Not implemented loss function!{sr_loss}")
        # self.contour = ContourLoss(10)
        # self.ssim = SSIM()

    def forward(self, input, target):
        if input.shape[2:] != target.shape[2:]:
            input = F.interpolate(input, size=target.shape[2:], mode='nearest')
        # 二分FocalLoss
        bce = self.focal(input, target)
        # ssim_loss = 1 - self.ssim(torch.sigmoid(input), target)
        # iou_loss = self.iou(input, target)
        # Dice系数计算
        dice = self.dice(input, target)
        # 边缘计算
        # contour_loss = self.contour(torch.sigmoid(input), target)
        return bce + dice  # + iou_loss  # + 1e-5 * contour_loss   # + ssim_loss


class KDLoss(nn.Module):
    def __init__(self):
        super(KDLoss, self).__init__()
        self.kldiv_loss = nn.KLDivLoss()
        self.bce_dice_loss = BCEDiceLoss()

    def forward(self, stu_pred, teacher_pred, target, temp=7, alpha=0.2):
        return self.kldiv_loss(torch.sigmoid(stu_pred / temp), torch.sigmoid(teacher_pred/temp)) * alpha + \
               self.bce_dice_loss(stu_pred, target) * (1.-alpha)


class ContourLoss(nn.Module):
    def __init__(self, weight):
        super(ContourLoss, self).__init__()
        self.weight = weight

    def forward(self, y_pred, y_true):
        '''
        y_true, y_pred: tensor of shape (B, C, H, W), where y_true[:,:,region_in_contour] == 1, y_true[:,:,region_out_contour] == 0.
        weight: scalar, length term weight.
        '''
        # length term
        delta_r = y_pred[:, :, 1:, :] - y_pred[:, :, :-1, :]  # horizontal gradient (B, C, H-1, W)
        delta_c = y_pred[:, :, :, 1:] - y_pred[:, :, :, :-1]  # vertical gradient   (B, C, H,   W-1)

        delta_r = delta_r[:, :, 1:, :-2] ** 2  # (B, C, H-2, W-2)
        delta_c = delta_c[:, :, :-2, 1:] ** 2  # (B, C, H-2, W-2)
        delta_pred = torch.abs(delta_r + delta_c)

        epsilon = 1e-8  # where is a parameter to avoid square root is zero in practice.
        lenth = torch.mean(torch.sqrt(delta_pred + epsilon))  # eq.(11) in the paper, mean is used instead of sum.

        # region term
        c_in = torch.ones_like(y_pred)
        c_out = torch.zeros_like(y_pred)

        region_in = torch.mean(y_pred * (y_true - c_in) ** 2)  # equ.(12) in the paper, mean is used instead of sum.
        region_out = torch.mean((1 - y_pred) * (y_true - c_out) ** 2)
        region = region_in + region_out

        loss = self.weight * lenth + region

        return loss


# nn.BCELoss(F.sigmoid(input), target)
# #多分类交叉熵, 用这个 loss 前面不需要加 Softmax 层
# nn.CrossEntropyLoss(input, target)
class WeightedBCELoss(nn.Module):
    """
    原文链接：https://blog.csdn.net/guligedong/article/details/122358507
    """
    def __init__(self, alpha=0.25, reduction='mean'):
        super(WeightedBCELoss, self).__init__()
        self.alpha = alpha
        self.reduction = reduction

    def forward(self, predict, target):
        pt = predict
        loss = -((1 - self.alpha) * target * torch.log(pt + 1e-5) + self.alpha * (1 - target) * torch.log(
            1 - pt + 1e-5))
        if self.reduction == 'mean':
            loss = torch.mean(loss)
        elif self.reduction == 'sum':
            loss = torch.sum(loss)

        return loss


class DiceLoss(nn.Module):
    """
    二分DiceLoss
    """

    def __init__(self):
        super(DiceLoss, self).__init__()

    def forward(self, input, target):
        N = target.size(0)
        smooth = 1e-5
        input = torch.sigmoid(input)

        input_flat = input.view(N, -1)
        target_flat = target.view(N, -1)

        intersection = input_flat * target_flat
        intersection_rev = (1 - input_flat) * (1 - target_flat)

        loss = 2 * (intersection.sum(1) + smooth) / (input_flat.sum(1) + target_flat.sum(1) + smooth)
        loss += 2 * (intersection_rev.sum(1) + smooth) / ((1 - input_flat).sum(1) + (1 - target_flat).sum(1) + smooth)
        loss = 1 - loss.sum() / (2 * N)

        return loss


class MulticlassDiceLoss(nn.Module):
    """
    requires one hot encoded target. Applies DiceLoss on each class iteratively.
    requires input.shape[0:1] and target.shape[0:1] to be (N, C) where N is
      batch size and C is number of classes
    """

    def __init__(self):
        super(MulticlassDiceLoss, self).__init__()
        self.dice = DiceLoss()

    def forward(self, input, target, weights=None):
        # Get channel num of target label
        C = target.shape[1]

        # if weights is None:
        # 	weights = torch.ones(C) #uniform weights for all classes


        totalLoss = 0

        for i in range(C):
            gt_i = torch.zeros_like(target)
            gt_i[target == i] = 1
            diceLoss = self.dice(input[:, i, :, :], gt_i)
            if weights is not None:
                diceLoss *= weights[i]
            totalLoss += diceLoss

        return totalLoss


class SoftIoULoss(nn.Module):
    def __init__(self, n_classes):
        super(SoftIoULoss, self).__init__()
        self.n_classes = n_classes

    @staticmethod
    def to_one_hot(tensor, n_classes):
        n, h, w = tensor.size()
        one_hot = torch.zeros(n, n_classes, h, w).scatter_(1, tensor.view(n, 1, h, w), 1)
        return one_hot

    def forward(self, input, target):
        # logit => N x Classes x H x W
        # target => N x H x W

        N = len(input)

        pred = F.sigmoid(input, dim=1)
        # target_onehot = self.to_one_hot(target, self.n_classes)

        # Numerator Product
        inter = pred * target
        # Sum over all pixels N x C x H x W => N x C
        inter = inter.view(N, self.n_classes, -1).sum(2)

        # Denominator
        union = pred + target - (pred * target)
        # Sum over all pixels N x C x H x W => N x C
        union = union.view(N, self.n_classes, -1).sum(2)

        loss = inter / (union + 1e-16)

        # Return average loss over classes and batch
        return 1-loss.mean()


# --------------------------- MULTICLASS LOSSES ---------------------------
class MultiFocalLoss(nn.Module):
    def __init__(self, alpha=0.85, gamma=1.5, weight=None, ignore_index=None):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.weight = weight
        self.ce_fn = nn.CrossEntropyLoss(weight=self.weight)

    def forward(self, preds, labels):
        logpt = -self.ce_fn(preds, labels)
        pt = torch.exp(logpt)
        loss = -((1 - pt) ** self.gamma) * self.alpha * logpt
        return loss


# --------------------------- BINARY LOSSES ---------------------------
class FocalLoss(nn.Module):
    def __init__(self, alpha=0.85, gamma=1.5, ignore_index=None):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.weight = torch.tensor([3.0]).cuda()
        self.ignore_index = ignore_index
        self.dice = DiceLoss()

    def forward(self, preds, labels):
        # if self.ignore_index is not None:
        #     mask = labels != self.ignore
        #     labels = labels[mask]
        #     preds = preds[mask]

        pt = self.dice(preds, labels)
        logpt = -torch.log(pt)
        loss = -((1 - pt) ** self.gamma) * self.alpha * logpt
        return loss


class LovaszHingeLoss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, input, target):
        input = input.squeeze(1)
        target = target.squeeze(1)
        loss = lovasz_hinge(input, target, per_image=True)

        return loss


# https://github.com/Po-Hsun-Su/pytorch-ssim/blob/master/pytorch_ssim/__init__.py
def gaussian(window_size, sigma):
    gauss = torch.Tensor([math.exp(-(x - window_size//2)**2/float(2*sigma**2)) for x in range(window_size)])
    return gauss/gauss.sum()


def create_window(window_size, channel):
    _1D_window = gaussian(window_size, 1.5).unsqueeze(1)
    _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
    window = Variable(_2D_window.expand(channel, 1, window_size, window_size).contiguous())
    return window


def _ssim(img1, img2, window, window_size, channel, size_average = True):
    mu1 = F.conv2d(img1, window, padding = window_size//2, groups = channel)
    mu2 = F.conv2d(img2, window, padding = window_size//2, groups = channel)

    mu1_sq = mu1.pow(2)
    mu2_sq = mu2.pow(2)
    mu1_mu2 = mu1*mu2

    sigma1_sq = F.conv2d(img1*img1, window, padding = window_size//2, groups = channel) - mu1_sq
    sigma2_sq = F.conv2d(img2*img2, window, padding = window_size//2, groups = channel) - mu2_sq
    sigma12 = F.conv2d(img1*img2, window, padding = window_size//2, groups = channel) - mu1_mu2

    C1 = 0.01**2
    C2 = 0.03**2

    ssim_map = ((2*mu1_mu2 + C1)*(2*sigma12 + C2))/((mu1_sq + mu2_sq + C1)*(sigma1_sq + sigma2_sq + C2))

    if size_average:
        return ssim_map.mean()
    else:
        return ssim_map.mean(1).mean(1).mean(1)


class SSIM(torch.nn.Module):
    def __init__(self, window_size=7, size_average=True):
        super(SSIM, self).__init__()
        self.window_size = window_size
        self.size_average = size_average
        self.channel = 1
        self.window = create_window(window_size, self.channel)

    def forward(self, img1, img2):
        (_, channel, _, _) = img1.size()
        if channel == self.channel and self.window.data.type() == img1.data.type():
            window = self.window
        else:
            window = create_window(self.window_size, channel)

            if img1.is_cuda:
                window = window.cuda(img1.get_device())
            window = window.type_as(img1)

            self.window = window
            self.channel = channel

        return _ssim(img1, img2, window, self.window_size, channel, self.size_average)


def _logssim(img1, img2, window, window_size, channel, size_average = True):
    mu1 = F.conv2d(img1, window, padding = window_size//2, groups = channel)
    mu2 = F.conv2d(img2, window, padding = window_size//2, groups = channel)

    mu1_sq = mu1.pow(2)
    mu2_sq = mu2.pow(2)
    mu1_mu2 = mu1*mu2

    sigma1_sq = F.conv2d(img1*img1, window, padding = window_size//2, groups = channel) - mu1_sq
    sigma2_sq = F.conv2d(img2*img2, window, padding = window_size//2, groups = channel) - mu2_sq
    sigma12 = F.conv2d(img1*img2, window, padding = window_size//2, groups = channel) - mu1_mu2

    C1 = 0.01**2
    C2 = 0.03**2

    ssim_map = ((2*mu1_mu2 + C1)*(2*sigma12 + C2))/((mu1_sq + mu2_sq + C1)*(sigma1_sq + sigma2_sq + C2))
    ssim_map = (ssim_map - torch.min(ssim_map))/(torch.max(ssim_map)-torch.min(ssim_map))
    ssim_map = -torch.log(ssim_map + 1e-8)

    if size_average:
        return ssim_map.mean()
    else:
        return ssim_map.mean(1).mean(1).mean(1)


class LOGSSIM(torch.nn.Module):
    def __init__(self, window_size = 11, size_average = True):
        super(LOGSSIM, self).__init__()
        self.window_size = window_size
        self.size_average = size_average
        self.channel = 1
        self.window = create_window(window_size, self.channel)

    def forward(self, img1, img2):
        (_, channel, _, _) = img1.size()

        if channel == self.channel and self.window.data.type() == img1.data.type():
            window = self.window
        else:
            window = create_window(self.window_size, channel)

            if img1.is_cuda:
                window = window.cuda(img1.get_device())
            window = window.type_as(img1)

            self.window = window
            self.channel = channel

        return _logssim(img1, img2, window, self.window_size, channel, self.size_average)


def ssim(img1, img2, window_size = 11, size_average = True):
    (_, channel, _, _) = img1.size()
    window = create_window(window_size, channel)

    if img1.is_cuda:
        window = window.cuda(img1.get_device())
    window = window.type_as(img1)

    return _ssim(img1, img2, window, window_size, channel, size_average)


if __name__ == "__main__":
    x = torch.randn([2, 4, 128, 128])
    target = torch.randint(0, 4, (2, 128, 128))
    loss_fn = MulticlassDiceLoss()
    dice = loss_fn(x, target)
    print(dice)