import argparse
import os
from glob import glob

import cv2
import torch
import torch.backends.cudnn as cudnn
import yaml
from torchvision.transforms import transforms as T
from albumentations.core.composition import Compose
from tqdm import tqdm
from metric.metrics import f1_loss, miou
from net.MobileV2UNet import MobileNetV2_UNet
from net.UNetImprove import MyNet
from dataset.dataset import Dataset, CrackLSDataset
from metric.metrics import iou_score
from utils.utils import AverageMeter
from albumentations import Resize


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default="CrackTree260_MyUNet+GNAM_woDS",
                        help='model name')

    args = parser.parse_args()

    return args


def main():
    args = parse_args()

    with open('Models/%s/config.yml' % args.name, 'r') as f:
        config = yaml.load(f, Loader=yaml.FullLoader)

    print('-'*20)
    for key in config.keys():
        print('%s: %s' % (key, str(config[key])))
    print('-'*20)

    cudnn.benchmark = True

    print("=> creating model %s" % config['arch'])
    model = MyNet()
    # Data loading code
    val_img_ids = glob(os.path.join(config['dataroot'], 'test', config['dataset'], 'images', '*' + config['img_ext']))
    print(len(val_img_ids))
    val_img_ids = [os.path.splitext(os.path.basename(p))[0] for p in val_img_ids]

    checkpoint = torch.load('Your Model Path' % config['name'])
    # according to the fold iou score to load
    model.load_state_dict(checkpoint['net'])
    model = model.cuda()
    model.eval()



    val_transform = T.Compose([
         T.Resize((config['input_h'], config['input_w'])),
         # T.CenterCrop((config['input_h'], config['input_h'])),
         # CenterCrop(config['input_h'], config['input_h']),
         T.ToTensor(),
    ])
    val_dataset = CrackLSDataset(
        img_ids=val_img_ids,
        img_dir=os.path.join(config['dataroot'], 'test', config['dataset'], 'images'),
        mask_dir=os.path.join(config['dataroot'], 'test', config['dataset'], 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'],
        transform=val_transform)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=False)
    iou_avg_meter = AverageMeter()
    dice_avg_meter = AverageMeter()
    pre_avg_meter = AverageMeter()
    acc_avg_meter = AverageMeter()
    recall_avg_meter = AverageMeter()
    f1_avg_meter = AverageMeter()
    mIoU_avg_meter = AverageMeter()
    gput = AverageMeter()
    cput = AverageMeter()

    count = 0
    for c in range(config['num_classes']):
        os.makedirs(os.path.join('outputs', config['name'], str(c)), exist_ok=True)
    with torch.no_grad():
        for index, sample in enumerate(tqdm(val_loader, total=len(val_loader))):
            input = sample['image'].cuda()
            target = sample['mask'].cuda()
            model = model.cuda()
            # compute output
            output = model(input)
            output = torch.sigmoid(output)
            iou, dice = iou_score(output, target)
            mIoU = miou(output, target)
            pred_vector = output.view(target.size(0), -1)
            target = target.view(target.size(0), -1)
            acc, pre, recall, f1 = f1_loss(target, pred_vector)
            iou_avg_meter.update(iou, input.size(0))
            dice_avg_meter.update(dice, input.size(0))
            pre_avg_meter.update(pre, input.size(0))
            acc_avg_meter.update(acc, input.size(0))
            recall_avg_meter.update(recall, input.size(0))
            f1_avg_meter.update(f1, input.size(0))
            mIoU_avg_meter.update(mIoU, input.size(0))
            output = output.cpu().numpy()
            output[output >= 0.5] = 1
            output[output < 0.5] = 0

            for i in range(len(output)):
                for c in range(config['num_classes']):
                    cv2.imwrite(os.path.join('outputs', config['name'], str(c), sample['img_id'][i] + '.jpg'),
                                (output[i, c] * 255).astype('uint8'))

    print('IoU: %.5f' % iou_avg_meter.avg)
    print('Dice: %.5f' % dice_avg_meter.avg)
    print('Acc: %.5f' % acc_avg_meter.avg)
    print('Pre: %.5f' % pre_avg_meter.avg)
    print('Recall: %.5f' % recall_avg_meter.avg)
    print('F1-Score: %.5f' % f1_avg_meter.avg)
    print('mIoU: %.5f' % mIoU_avg_meter.avg)

    torch.cuda.empty_cache()


if __name__ == '__main__':
    main()
